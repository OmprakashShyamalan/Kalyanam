from django.apps import AppConfig


class MarriageConfig(AppConfig):
    name = 'Marriage'
