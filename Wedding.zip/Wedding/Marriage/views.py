from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    my_dict = {'insert_me':'Hi Darling!!!'}
    return render(request,'Marriage/index.html',context=my_dict)

def index2(request):
    return HttpResponse("This is Working")
