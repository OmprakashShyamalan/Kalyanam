from django.urls import include, path
from Marriage import views

urlpatterns=[
    path('',views.index2,name='index2'),
]
